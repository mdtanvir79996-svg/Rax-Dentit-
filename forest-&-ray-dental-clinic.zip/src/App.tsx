import { motion } from "motion/react";
import { 
  Phone, 
  Mail, 
  MapPin, 
  ChevronRight, 
  Star, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  Sparkles,
  Camera,
  Layers,
  Search,
  MessageCircle,
  Calendar,
  Menu,
  X,
  Instagram,
  Facebook,
  Linkedin
} from "lucide-react";
import { useState, useEffect } from "react";

// --- Types ---
interface Service {
  id: string;
  title: string;
  description: string;
  benefits: string[];
  icon: any;
}

// --- Data ---
const SERVICES: Service[] = [
  {
    id: "cosmetic",
    title: "Cosmetic Dentistry",
    description: "Enhance your smile's aesthetics with our bespoke cosmetic solutions.",
    benefits: ["Hollywood Smile", "Stain Removal", "Confidence Boost"],
    icon: Sparkles
  },
  {
    id: "implants",
    title: "Dental Implants",
    description: "Permanent, natural-looking tooth replacement using titanium fixtures.",
    benefits: ["Durability", "Bone Preservation", "Self-Confidence"],
    icon: Layers
  },
  {
    id: "ortho",
    title: "Orthodontics",
    description: "Straighten your teeth with modern braces and clear aligners.",
    benefits: ["Proper Alignment", "Improved Bite", "Discreet Options"],
    icon: Search
  },
  {
    id: "whitening",
    title: "Teeth Whitening",
    description: "Professional whitening treatments for a brighter, radiant smile.",
    benefits: ["Instant Results", "Safe Treatment", "Professional Grade"],
    icon: Camera
  },
  {
    id: "root-canal",
    title: "Root Canal",
    description: "Saving damaged teeth with pain-free, expert endodontic care.",
    benefits: ["Pain Relief", "Tooth Retention", "Expert Handling"],
    icon: ShieldCheck
  },
  {
    id: "hygiene",
    title: "Hygiene & Cleaning",
    description: "Preventive care to maintain optimal oral health and freshness.",
    benefits: ["Gum Health", "Plaque Removal", "Fresh Breath"],
    icon: CheckCircle2
  }
];

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${isScrolled ? "glass py-4 shadow-sm" : "bg-transparent py-6"}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <div className="flex items-center gap-2 group cursor-pointer">
          <div className="w-10 h-10 bg-forest rounded-lg flex items-center justify-center text-gold group-hover:rotate-12 transition-transform">
            <Sparkles size={24} />
          </div>
          <div>
            <span className={`text-xl font-serif font-bold ${isScrolled ? "text-forest" : "text-white"}`}>Forest & Ray</span>
            <p className={`text-[10px] tracking-widest uppercase font-medium ${isScrolled ? "text-gold" : "text-gold/80"}`}>Dental Excellence</p>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-8">
          {["Services", "About", "Patient Experience", "Education", "Contact"].map((item) => (
            <a 
              key={item} 
              href={`#${item.toLowerCase().replace(/\s+/g, '-')}`} 
              className={`text-sm font-medium hover:text-gold transition-colors ${isScrolled ? "text-forest" : "text-white"}`}
            >
              {item}
            </a>
          ))}
          <a href="#booking" className="btn-secondary !py-2.5 !text-sm">Book Appointment</a>
        </div>

        <button 
          className={`md:hidden ${isScrolled ? "text-forest" : "text-white"}`}
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-full left-0 w-full bg-white shadow-xl p-6 flex flex-col gap-4 md:hidden"
        >
          {["Services", "About", "Patient Experience", "Education", "Contact"].map((item) => (
            <a 
              key={item} 
              href={`#${item.toLowerCase().replace(/\s+/g, '-')}`} 
              className="text-forest font-medium py-2 border-b border-forest/10"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {item}
            </a>
          ))}
          <a href="#booking" className="btn-primary text-center mt-2" onClick={() => setIsMobileMenuOpen(false)}>Book Online</a>
        </motion.div>
      )}
    </nav>
  );
};

const Hero = () => {
  return (
    <section className="relative h-screen flex items-center overflow-hidden">
      {/* Background with parallax effect */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center grayscale-[20%]"
        style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1629909613654-28e377c37b09?q=80&w=2070&auto=format&fit=crop")', filter: 'brightness(0.3)' }}
      />
      
      <div className="max-w-7xl mx-auto px-6 relative z-10 grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <div className="flex items-center gap-2 mb-6">
            <span className="w-12 h-[1px] bg-gold"></span>
            <span className="text-gold uppercase tracking-[0.2em] text-sm font-semibold">Premium Dental Care in London</span>
          </div>
          <h1 className="text-6xl md:text-8xl text-white mb-6 leading-[1.1]">
            Transform <br />
            <span className="text-gold italic">Your Smile</span> <br />
            With Experts
          </h1>
          <p className="text-white/80 text-lg mb-10 max-w-lg leading-relaxed font-light">
            Pain-free treatments, advanced Swiss technology, and a legacy of excellence since 2007. Experience personalized dental care in the heart of London.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a href="#booking" className="btn-secondary text-center">Book Your Visit</a>
            <a href="tel:+442081246138" className="btn-primary !bg-white/10 backdrop-blur-md !border !border-white/20 hover:!bg-white/20 flex items-center justify-center gap-2">
              <Phone size={18} className="text-gold" />
              Call Now
            </a>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="hidden lg:block relative"
        >
          <div className="w-[500px] h-[500px] rounded-full border-2 border-gold/30 absolute -top-10 -right-10 animate-pulse"></div>
          <div className="w-[450px] h-[600px] bg-white/5 backdrop-blur-xl rounded-[40px] border border-white/20 p-8 shadow-2xl overflow-hidden relative group">
             <div className="absolute inset-0 bg-gold/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
             <div className="relative z-10">
                <div className="flex gap-1 mb-4">
                  {[1,2,3,4,5].map(i => <Star key={i} size={16} className="fill-gold text-gold" />)}
                </div>
                <h3 className="text-white text-2xl mb-4 italic">"The most professional and caring team I've ever encountered. My confidence has completely changed."</h3>
                <p className="text-gold font-medium">— Sarah Jennings, London</p>
             </div>
             <div className="mt-12 overflow-hidden rounded-2xl h-80">
                <img 
                  src="https://images.unsplash.com/photo-1548142813-c348350df52b?q=80&w=1978&auto=format&fit=crop" 
                  className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700 hover:scale-110" 
                  alt="Happy Patient"
                />
             </div>
          </div>
        </motion.div>
      </div>

      {/* Stats Bar */}
      <div className="absolute bottom-10 w-full z-10 px-6">
        <div className="max-w-7xl mx-auto glass rounded-2xl p-6 md:p-10 grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="text-center">
            <p className="text-3xl font-serif text-forest font-bold mb-1">17+</p>
            <p className="text-xs uppercase tracking-widest text-gold font-semibold">Years Experience</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-serif text-forest font-bold mb-1">7 Days</p>
            <p className="text-xs uppercase tracking-widest text-gold font-semibold">Weekly Availability</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-serif text-forest font-bold mb-1">10k+</p>
            <p className="text-xs uppercase tracking-widest text-gold font-semibold">Happy Patients</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-serif text-forest font-bold mb-1">4.6/5</p>
            <p className="text-xs uppercase tracking-widest text-gold font-semibold">Trustpilot Rating</p>
          </div>
        </div>
      </div>
    </section>
  );
};

const Services = () => {
  return (
    <section id="services" className="py-32 bg-cream">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-gold uppercase tracking-[0.3em] text-sm font-bold mb-4"
          >
            Specialized Treatments
          </motion.p>
          <h2 className="text-4xl md:text-6xl text-forest mb-6">Our Services</h2>
          <p className="text-forest/60 max-w-2xl mx-auto text-lg leading-relaxed">
            From routine checkups to complex surgeries, our world-class specialists provide comprehensive care using advanced medical technology.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES.map((service, idx) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              viewport={{ once: true }}
              className="bg-white p-10 rounded-[40px] shadow-sm card-hover relative group overflow-hidden border border-forest/5"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-gold/5 rounded-bl-[80px] transition-all group-hover:bg-gold/10"></div>
              <div className="w-16 h-16 bg-cream rounded-2xl flex items-center justify-center text-forest mb-8 group-hover:bg-forest group-hover:text-gold transition-colors duration-500">
                <service.icon size={32} />
              </div>
              <h3 className="text-2xl font-bold text-forest mb-4">{service.title}</h3>
              <p className="text-forest/70 mb-8 leading-relaxed">
                {service.description}
              </p>
              <ul className="space-y-3 mb-8">
                {service.benefits.map((benefit, bIdx) => (
                  <li key={bIdx} className="flex items-center gap-3 text-sm text-forest/80 font-medium">
                    <CheckCircle2 size={16} className="text-gold" />
                    {benefit}
                  </li>
                ))}
              </ul>
              <button className="flex items-center gap-2 text-forest font-bold group-hover:text-gold transition-colors">
                Book Consultation <ChevronRight size={18} />
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Experience = () => {
  return (
    <section id="patient-experience" className="bg-forest py-32 rounded-[60px] mx-4 md:mx-10 my-20">
      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
        <div className="relative">
          <div className="grid grid-cols-2 gap-4">
            <div className="pt-12">
               <motion.img 
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                src="https://images.unsplash.com/photo-1598256989800-fe5f95da9787?q=80&w=2070&auto=format&fit=crop" 
                alt="Clinic Interior" 
                className="rounded-3xl h-[400px] w-full object-cover shadow-2xl"
               />
            </div>
            <div>
               <motion.img 
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
                src="https://images.unsplash.com/photo-1516549226039-a720619d646b?q=80&w=2070&auto=format&fit=crop" 
                alt="High Tech Equipment" 
                className="rounded-3xl h-[400px] w-full object-cover shadow-2xl"
               />
            </div>
          </div>
          <div className="absolute -bottom-10 -left-10 bg-gold p-8 rounded-3xl shadow-xl hidden md:block">
            <div className="flex items-center gap-4 text-white">
              <Clock size={40} />
              <div>
                <p className="text-sm uppercase tracking-widest font-bold">Open 7 Days</p>
                <p className="text-2xl font-serif">8 AM - 9 PM</p>
              </div>
            </div>
          </div>
        </div>

        <div className="text-white">
          <p className="text-gold uppercase tracking-[0.3em] text-sm font-bold mb-4">Patient-First Approach</p>
          <h2 className="text-4xl md:text-6xl mb-8">The Gold Standard of Comfort</h2>
          <div className="space-y-8">
            <div className="flex gap-6">
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center shrink-0 text-gold">
                <ShieldCheck />
              </div>
              <div>
                <h4 className="text-xl font-bold mb-2">Pain-Free Dentistry</h4>
                <p className="text-white/60">We utilize advanced numbing technology and sedation options to ensure your visit is completely relaxed and stress-free.</p>
              </div>
            </div>
            <div className="flex gap-6">
               <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center shrink-0 text-gold">
                <MessageCircle />
              </div>
              <div>
                <h4 className="text-xl font-bold mb-2">Anxiety-Friendly Environment</h4>
                <p className="text-white/60">Our staff is specially trained in dental phobia management, providing a warm, supportive atmosphere for nervous patients.</p>
              </div>
            </div>
            <div className="flex gap-6">
               <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center shrink-0 text-gold">
                <Calendar />
              </div>
              <div>
                <h4 className="text-xl font-bold mb-2">Same-Day Appointments</h4>
                <p className="text-white/60">Dental emergencies don't wait. We offer same-day emergency slots to get you back to your best as quickly as possible.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const BookingForm = () => {
  return (
    <section id="booking" className="py-32 bg-cream overflow-hidden relative">
      {/* Decorative gradient */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gold/5 rounded-full blur-[120px] pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="bg-white rounded-[60px] shadow-2xl overflow-hidden grid lg:grid-cols-5 border border-forest/5">
          <div className="lg:col-span-2 bg-gold p-12 md:p-20 text-white relative">
            <div className="absolute top-0 right-0 p-12 opacity-10">
              <Sparkles size={180} />
            </div>
            <h2 className="text-4xl md:text-5xl mb-8 leading-tight">Start Your Transformation</h2>
            <p className="text-white/80 mb-12 text-lg font-light leading-relaxed">
              Book your private consultation today and take the first step towards a healthier, more confident smile.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                  <Phone size={18} />
                </div>
                <p className="font-medium">+44 20 8124 6138</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                  <Mail size={18} />
                </div>
                <p className="font-medium">info@forestray.dentist</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                  <MapPin size={18} />
                </div>
                <p className="font-medium">8F Gilbert Place, London WC1A 2JD</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-3 p-12 md:p-20">
            <form className="space-y-8" onSubmit={(e) => e.preventDefault()}>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-gold font-bold">Full Name</label>
                  <input type="text" placeholder="John Doe" className="w-full bg-cream border-none p-4 rounded-2xl focus:ring-2 focus:ring-gold outline-none transition-all" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-gold font-bold">Phone Number</label>
                  <input type="tel" placeholder="+44 7000 000 000" className="w-full bg-cream border-none p-4 rounded-2xl focus:ring-2 focus:ring-gold outline-none transition-all" />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-gold font-bold">Service Required</label>
                  <select className="w-full bg-cream border-none p-4 rounded-2xl focus:ring-2 focus:ring-gold outline-none transition-all appearance-none cursor-pointer">
                    <option>Cosmetic Dentistry</option>
                    <option>Dental Implants</option>
                    <option>Teeth Whitening</option>
                    <option>Orthodontics</option>
                    <option>General Checkup</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-gold font-bold">Preferred Date</label>
                  <input type="date" className="w-full bg-cream border-none p-4 rounded-2xl focus:ring-2 focus:ring-gold outline-none transition-all cursor-pointer" />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-gold font-bold">Additional Notes (Optional)</label>
                <textarea rows={4} placeholder="Tell us about your concerns..." className="w-full bg-cream border-none p-4 rounded-2xl focus:ring-2 focus:ring-gold outline-none transition-all"></textarea>
              </div>

              <button className="btn-primary w-full py-5 text-lg">Send Request</button>
              <p className="text-center text-forest/40 text-xs italic">
                Our patient coordinator will contact you within 2 hours to confirm your booking.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-forest text-white pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-24">
          <div className="space-y-8">
             <div className="flex items-center gap-2 group cursor-pointer">
              <div className="w-10 h-10 bg-gold rounded-lg flex items-center justify-center text-forest">
                <Star size={24} />
              </div>
              <div>
                <span className="text-xl font-serif font-bold text-white">Forest & Ray</span>
                <p className="text-[10px] tracking-widest uppercase font-medium text-gold">Dental Excellence</p>
              </div>
            </div>
            <p className="text-white/60 leading-relaxed font-light">
              Since 2007, we've been helping London smile with confidence. Our private clinic offers world-class dentistry in a premium, caring environment.
            </p>
            <div className="flex gap-4">
              <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-gold transition-colors cursor-pointer">
                <Instagram size={18} />
              </div>
              <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-gold transition-colors cursor-pointer">
                <Facebook size={18} />
              </div>
              <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-gold transition-colors cursor-pointer">
                <Linkedin size={18} />
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-8 text-gold">Quick Links</h4>
            <ul className="space-y-4 text-white/60">
              <li><a href="#" className="hover:text-gold transition-colors">Our Specialists</a></li>
              <li><a href="#" className="hover:text-gold transition-colors">Patient Case Studies</a></li>
              <li><a href="#" className="hover:text-gold transition-colors">Emergency Services</a></li>
              <li><a href="#" className="hover:text-gold transition-colors">Payment Plans</a></li>
              <li><a href="#" className="hover:text-gold transition-colors">Careers</a></li>
            </ul>
          </div>

          <div>
             <h4 className="text-lg font-bold mb-8 text-gold">Services</h4>
             <ul className="space-y-4 text-white/60">
              <li><a href="#" className="hover:text-gold transition-colors">Dental Implants</a></li>
              <li><a href="#" className="hover:text-gold transition-colors">Invisalign & Ortho</a></li>
              <li><a href="#" className="hover:text-gold transition-colors">Hollywood Veneers</a></li>
              <li><a href="#" className="hover:text-gold transition-colors">Gum Surgery</a></li>
              <li><a href="#" className="hover:text-gold transition-colors">Sedation Dentistry</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-8 text-gold">Office Hours</h4>
            <ul className="space-y-4 text-white/60 text-sm">
              <li className="flex justify-between"><span>Monday - Saturday</span> <span>08:00 - 21:00</span></li>
              <li className="flex justify-between"><span>Sunday</span> <span>10:00 - 18:00</span></li>
              <li className="pt-4 flex gap-3 italic text-gold">
                <ShieldCheck size={16} /> 7-Day availability for emergencies.
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-12 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-sm text-white/40">© 2026 Forest & Ray Dental Clinic. All Rights Reserved.</p>
          <div className="flex gap-8 text-sm text-white/40">
            <a href="#" className="hover:text-gold">Privacy Policy</a>
            <a href="#" className="hover:text-gold">Terms of Service</a>
            <a href="#" className="hover:text-gold">Cookie Settings</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  return (
    <div className="selection:bg-gold selection:text-white">
      <Navbar />
      <Hero />
      <Services />
      
      {/* Branding Section */}
      <section className="py-20 bg-forest overflow-hidden">
        <div className="flex whitespace-nowrap overflow-hidden group">
           {[...Array(4)].map((_, i) => (
             <div key={i} className="flex items-center gap-20 animate-infinite-scroll group-hover:pause pr-20">
                <span className="text-white/20 text-6xl md:text-8xl font-serif uppercase">Pain-Free Dentistry</span>
                <span className="text-gold/40 text-6xl md:text-8xl italic uppercase leading-none pb-2">Est 2007</span>
                <span className="text-white/20 text-6xl md:text-8xl font-serif uppercase">Experienced Specialists</span>
                <span className="text-gold/40 text-6xl md:text-8xl italic uppercase leading-none pb-2">Open 7 Days</span>
             </div>
           ))}
        </div>
      </section>

      <Experience />

      {/* Why Choose Us Minimalist Grid */}
      <section id="about" className="py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-20 items-end mb-20">
            <div>
              <p className="text-gold uppercase tracking-[0.3em] text-sm font-bold mb-4">Why Us</p>
              <h2 className="text-5xl md:text-7xl text-forest leading-tight">Decades of Dental Excellence</h2>
            </div>
            <p className="text-lg text-forest/60 max-w-md leading-relaxed pb-2">
              We combine artisan craftsmanship with high-precision technology to provide results that don't just look great, but last a lifetime.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-12">
            {[
              {
                title: "Central London Location",
                desc: "Located at 8F Gilbert Place, our clinic is easily accessible from anywhere in the city.",
                icon: MapPin
              },
              {
                title: "Advanced Technology",
                desc: "Equipped with the latest 3D imaging and micro-dentistry tools for pin-point accuracy.",
                icon: ShieldCheck
              },
              {
                title: "Patient Advocacy",
                desc: "Transparent treatment plans and fixed pricing. No hidden costs, ever.",
                icon: CheckCircle2
              }
            ].map((item, idx) => (
              <div key={idx} className="group cursor-default">
                <div className="w-14 h-14 bg-cream rounded-2xl flex items-center justify-center text-gold mb-6 group-hover:bg-gold group-hover:text-white transition-all transform group-hover:scale-110">
                   <item.icon size={28} />
                </div>
                <h4 className="text-2xl font-bold text-forest mb-4">{item.title}</h4>
                <p className="text-forest/60 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <BookingForm />
      
      {/* Education Section */}
      <section id="education" className="py-32 bg-cream">
         <div className="max-w-7xl mx-auto px-6">
            <div className="flex flex-col md:flex-row justify-between items-end gap-10 mb-16">
               <div className="max-w-2xl">
                 <h2 className="text-4xl md:text-5xl text-forest mb-4">Invest in Your Oral Future</h2>
                 <p className="text-forest/60 text-lg">Knowledge is the foundation of preventive care. Learn how we help you maintain long-term brilliance.</p>
               </div>
               <button className="btn-primary">View All Resources</button>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
               {[
                 {
                   img: "https://images.unsplash.com/photo-1606811971618-4486d14f3f99?q=80&w=1974&auto=format&fit=crop",
                   title: "The Science of Smile Confidence",
                   category: "Cosmetic"
                 },
                 {
                   img: "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?q=80&w=2070&auto=format&fit=crop",
                   title: "Modern Implants: What to Expect",
                   category: "Surgery"
                 }
               ].map((post, i) => (
                 <div key={i} className="group relative h-[400px] rounded-[40px] overflow-hidden cursor-pointer">
                    <img src={post.img} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt={post.title} />
                    <div className="absolute inset-0 bg-gradient-to-t from-forest/90 via-forest/20 to-transparent p-12 flex flex-col justify-end">
                       <span className="text-gold text-xs uppercase tracking-[0.2em] font-bold mb-2">{post.category}</span>
                       <h3 className="text-3xl text-white font-serif">{post.title}</h3>
                    </div>
                 </div>
               ))}
            </div>
         </div>
      </section>

      <Footer />
      
      <style>{`
        @keyframes infinite-scroll {
          from { transform: translateX(0); }
          to { transform: translateX(-100%); }
        }
        .animate-infinite-scroll {
          animation: infinite-scroll 40s linear infinite;
        }
        .pause {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  );
}
